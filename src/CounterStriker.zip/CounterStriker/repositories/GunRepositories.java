package CounterStriker.repositories;

import CounterStriker.models.guns.Gun;

import java.util.*;

public class GunRepositories implements Repository{
    private Map<String, Gun> models;

    protected GunRepositories() {
        this.models = new HashMap<>();
    }

    @Override
    public Collection getModels() {
        return null;
    }

    @Override
    public void add(Object model) {

    }

    @Override
    public boolean remove(Object model) {
        return false;
    }

    @Override
    public Object findByName(String name) {
        return null;
    }
}
