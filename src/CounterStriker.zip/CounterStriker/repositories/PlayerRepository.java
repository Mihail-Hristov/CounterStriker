package CounterStriker.repositories;

import CounterStriker.models.players.Player;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class PlayerRepository implements Repository{
    private Map<String, Player> models;

    public PlayerRepository() {
        this.models = new HashMap<>();
    }


    @Override
    public Collection getModels() {
        return null;
    }

    @Override
    public void add(Object model) {

    }

    @Override
    public boolean remove(Object model) {
        return false;
    }

    @Override
    public Object findByName(String name) {
        return null;
    }
}
