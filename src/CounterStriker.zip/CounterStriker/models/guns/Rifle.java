package CounterStriker.models.guns;

public class Rifle extends GunImpl{


    protected Rifle(String name, int bulletsCount) {
        super(name, bulletsCount);
    }

    @Override
    public int fire() {
        if (this.getBulletsCount() < 10) {
            return 0;
        }

        return 10;
    }
}
